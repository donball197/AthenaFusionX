// src/orchestrator.rs — v3.4 SOVEREIGN API BRIDGE
use reqwest::Client;
use serde_json::{json, Value};
use tokio::sync::broadcast;
use crate::neural_agent::ContextPacket;

pub struct Orchestrator;

impl Orchestrator {
    pub fn new() -> Self {
        Self
    }

    pub async fn run(
        &self,
        prompt: String,
        ctx: ContextPacket,
        client: &Client,
        api_key: &str,
        tx: Option<broadcast::Sender<String>>,
    ) -> Result<String, String> {
        // ⚡ FIX: Use explicit type mapping to help compiler infer &str
        let model = ctx.system_prompt.as_ref()
            .and_then(|p: &String| {
                p.split("Model: ").nth(1)
            })
            .map(|m: &str| m.trim_end_matches('.').to_string())
            .unwrap_or_else(|| "gemma-4-26b-a4b-it".to_string());

        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}",
            model, api_key
        );

        let mut parts = vec![];
        if let Some(ref sys_prompt) = ctx.system_prompt {
            parts.push(json!({"text": format!("SYSTEM DIRECTIVE:\n{}\n\n", sys_prompt)}));
        }
        parts.push(json!({"text": prompt}));

        let payload = json!({
            "contents": [{"parts": parts}],
            "generationConfig": {
                "temperature": 0.0,
                "maxOutputTokens": 4096,
                "topP": 0.8
            }
        });

        if let Some(ref sender) = tx {
            let _ = sender.send(json!({
                "type": "NEURAL_STREAM",
                "payload": format!("\x1b[36m>> [UPLINK] Transmitting payload to {}...\x1b[0m\n", model)
            }).to_string());
        }

        let res = client.post(&url).json(&payload).send().await
            .map_err(|e| format!("NETWORK_FAULT: {}", e))?;

        if !res.status().is_success() {
            let err_text = res.text().await.unwrap_or_default();
            return Err(format!("API_FAULT: {}", err_text));
        }

        let response_json: Value = res.json().await
            .map_err(|e| format!("JSON_PARSE_FAULT: {}", e))?;

        let text = response_json["candidates"][0]["content"]["parts"][0]["text"]
            .as_str()
            .unwrap_or("")
            .to_string();

        Ok(text)
    }
}
