use std::io::{self, Write};
use std::sync::Arc;
use crate::server::AppState;
use crate::task_manager;

pub fn inject_workspace_dna(directive: &str) -> String {
    let directive = directive.trim();
    if directive.is_empty() { return String::new(); }

    let schema = r#"
[NEXUS SOVEREIGN KERNEL — v3.5 DEVOPS]
You are a DevOps Agentic Team on ARM64. You manage the VMO microkernel and the Git repository.

OUTPUT RULES:
- Reasoning: ONLY inside <THOUGHT></THOUGHT> (max 3 short sentences).
- Actions: ONLY inside <ACTION></ACTION> — sequence multiple actions in the JSON array.
- Safety: Every 'execute_command' is automatically backed up by a Lazarus Snapshot.

AVAILABLE ACTIONS:
{"type": "git_action", "command": "status|commit|branch", "message": "description"}
{"type": "execute_command", "command": "cargo check | npm run build"}
{"type": "write_file", "path": "src/module.rs", "content": "..."}
{"type": "lazarus_snapshot", "path": "src/", "tag": "backup_tag"}
{"type": "vmo_create"}
{"type": "search_memory", "query": "term"}
{"type": "halt"}

STRATEGY:
1. Use 'git_action' branch to isolate new features.
2. Use 'execute_command' to verify builds.
3. If build fails, use Lazarus or Git to revert.
"#;

    format!(
        "SYSTEM_CONTEXT: [SOVEREIGN_DEVOPS v3.5]\n{}\n\nDIRECTIVE: {}",
        schema, directive
    )
}

pub async fn run_cli_loop(state: Arc<AppState>) -> io::Result<()> {
    let stdin = io::stdin();
    let mut rx = state.tx.subscribe();
    
    // Background task to pump neural streams to stdout
    tokio::spawn(async move {
        while let Ok(msg) = rx.recv().await {
            if let Ok(val) = serde_json::from_str::<serde_json::Value>(&msg) {
                if val["type"] == "NEURAL_STREAM" {
                    if let Some(text) = val["payload"].as_str() { 
                        print!("{}", text); 
                        io::stdout().flush().ok(); 
                    }
                } else if val["type"] == "NEURAL_THOUGHT" {
                    if let Some(text) = val["payload"].as_str() { 
                        println!("\x1b[34m>> [THOUGHT] {}\x1b[0m", text.trim()); 
                    }
                }
            }
        }
    });
    
    tokio::time::sleep(tokio::time::Duration::from_millis(200)).await;
    
    loop {
        print!("\r\x1b[K\x1b[1;32mNEXUS_OS >> (Paste directive, press Enter TWICE to execute)\n> \x1b[0m");
        io::stdout().flush().ok();
        
        // ⚡ MULTI-LINE BUFFER: Reads until an empty line is detected
        let mut directive_buffer = String::new();
        loop {
            let mut line = String::new();
            if stdin.read_line(&mut line)? == 0 { break; }
            if line.trim().is_empty() { break; }
            directive_buffer.push_str(&line);
        }
        
        let directive = directive_buffer.trim();
        if directive.is_empty() { continue; }
        if directive == "exit" || directive == "quit" { break; }
        
        task_manager::send_task(
            state.orchestrator.clone(), 
            &state.client, 
            &state.api_key, 
            &inject_workspace_dna(directive), 
            state.memory.clone(), 
            state.vmo_state.clone(), 
            state.tx.clone()
        ).await;
        println!();
    }
    Ok(())
}
