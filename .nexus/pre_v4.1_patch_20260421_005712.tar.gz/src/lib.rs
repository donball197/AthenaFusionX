// ═══════════════════════════════════════════════════════════════════════
//  PROJECT NEXUS SINGULARITY v0.2.2 - KERNEL DNA
// ═══════════════════════════════════════════════════════════════════════
pub mod agent_protocol; pub mod agents; pub mod alloc; pub mod arbiter_agent; 
pub mod auth; pub mod broker; pub mod cli; pub mod component_runner; pub mod diff; 
pub mod dream_cycle; pub mod executor; pub mod factory; pub mod fs_utils; 
pub mod hiram_core; pub mod inquisitor; pub mod json_parser; pub mod kernel; 
pub mod lazarus_vault; pub mod litert_bridge; pub mod local_llm; pub mod memory; 
pub mod memory_bridge; pub mod metrics; pub mod mission_control; pub mod mission_planner; 
pub mod mission_queue; pub mod neural_agent; pub mod orchestrator; pub mod podman; 
pub mod reflex; pub mod resonator; pub mod sandbox; pub mod scheduler; 
pub mod scraper_drone; pub mod self_healing_engine; pub mod server; 
pub mod server_terminal; pub mod services; pub mod stream_optimizer; pub mod swarm; 
pub mod system_monitor; pub mod task_manager; pub mod thermal_governor; 
pub mod vision; pub mod vitals_handler; pub mod void_walker; pub mod ws_bridge; 
pub mod ziggy_llm;
pub mod vmo_handler;
pub mod logic_engine;
