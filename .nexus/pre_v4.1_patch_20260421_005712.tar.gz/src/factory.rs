/**
 * NEXUS AGENT FACTORY — v3.1 (MoE Sovereign Fusion)
 * Handles Turn-based Escalation, Mission Selection, and Product Certification.
 */

pub struct AgentFactory;

impl AgentFactory {
    /// get_model_for_turn: The 26B MoE is our primary driver. 
    /// We only escalate to the dense 31B or Gemini if the MoE hits a syntax fracture.
    pub fn get_model_for_turn(turn: usize, current_error_count: usize) -> &'static str {
        if turn >= 4 || current_error_count > 2 {
            return "gemini-2.5-pro"; // Emergency Deep Reasoning
        }
        if current_error_count > 0 {
            return "gemma-4-31b-it"; // Dense fallback for strict JSON recovery
        }
        
        "gemma-4-26b-a4b-it" // Primary FSM Engine (MoE)
    }

    /// select_model_for_mission: Direct model assignment for specific industries.
    pub fn select_model_for_mission(mission_type: &str) -> &'static str {
        match mission_type {
            "robotics" | "ros" => "gemini-robotics-er-1.5-preview",
            "security" | "audit" => "gemma-4-31b-it",
            "coding" | "refactor" | "dream" => "gemma-4-26b-a4b-it",
            _ => "gemma-4-26b-a4b-it" // Defaulting to the MoE
        }
    }

    pub fn certify_product(title: &str, client: &str, content: &str) -> String {
        format!(
            "--- NEXUS INDUSTRIAL DELIVERABLE ---\nCLIENT: {}\nTITLE: {}\nSUBSTRATE: ARM64_SOVEREIGN\n------------------------------------\n\n{}\n\n------------------------------------\nSTAMP: VERIFIED_AGENT_DNA",
            client, title, content
        )
    }
}
