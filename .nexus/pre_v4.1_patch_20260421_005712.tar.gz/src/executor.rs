// src/executor.rs — v3.7 Autonomic DevOps Executor
use crate::agent_protocol::AgentAction;
use crate::memory::MemoryPalace;
use crate::server::VmoState;
use crate::lazarus_vault::LazarusVault;
use std::sync::Arc;
use tokio::sync::Mutex;
use tokio::process::Command;

#[derive(Debug, PartialEq, Clone, Copy)]
pub enum FsmState { Idle, Executing, Complete, Fault }

pub struct RoboticExecutor { pub current_state: FsmState }

impl RoboticExecutor {
    pub fn new() -> Self { Self { current_state: FsmState::Idle } }

    pub fn transition(&mut self, next_state: FsmState) {
        if self.current_state != FsmState::Complete && self.current_state != FsmState::Fault {
            self.current_state = next_state;
        }
    }

    pub async fn execute_handle(
        &mut self,
        actions: Vec<AgentAction>,
        _memory: Arc<Mutex<MemoryPalace>>, // ⚡ FIX: Added underscore to silence warning
        vmo_state: Arc<Mutex<VmoState>>,
    ) -> Result<Vec<String>, String> {
        self.transition(FsmState::Executing);
        let mut results = Vec::new();

        for action in actions {
            if self.current_state == FsmState::Complete || self.current_state == FsmState::Fault { break; }

            match action {
                AgentAction::ExecuteCommand { command } => {
                    println!("\x1b[33m>> [REFLEX] Pre-execution safety snapshot...\x1b[0m");
                    let _ = LazarusVault::auto_snapshot("src/", "pre_command_backup").await;
                    
                    let output = Command::new("sh").arg("-c").arg(&command).output().await.map_err(|e| e.to_string())?;
                    results.push(String::from_utf8_lossy(&output.stdout).trim().to_string());
                }

                AgentAction::GitAction { command, message } => {
                    let git_cmd = match command.as_str() {
                        "commit" => format!("git add . && git commit -m \"{}\"", message.unwrap_or_else(|| "NEXUS_AUTO_COMMIT".into())),
                        "status" => "git status".to_string(),
                        "branch" => format!("git checkout -b {}", message.unwrap_or_else(|| "nexus-patch".into())),
                        _ => "git status".to_string(),
                    };
                    let output = Command::new("sh").arg("-c").arg(&git_cmd).output().await.map_err(|e| e.to_string())?;
                    results.push(format!("GIT: {}", String::from_utf8_lossy(&output.stdout).trim()));
                }

                AgentAction::LazarusSnapshot { path, tag } => {
                    let tag_str = tag.unwrap_or_else(|| "ghost_auto".to_string());
                    match LazarusVault::auto_snapshot(&path, &tag_str).await {
                        Ok(snap) => results.push(format!("LAZARUS_SNAPSHOT: {} | Hash: {}", path, &snap.hash[..8])),
                        Err(e) => results.push(format!("LAZARUS_ERROR: {}", e)),
                    }
                }

                AgentAction::VmoCreate => {
                    let handle = unsafe { crate::kernel::zx_vmo_create_native(4096) };
                    crate::kernel::register_handle(handle, crate::kernel::HandleType::Vmo(handle));
                    vmo_state.lock().await.last_parent = Some(handle);
                    results.push(format!("VMO_CREATE: 0x{:x}", handle));
                }

                AgentAction::Halt => {
                    results.push("SEQUENCE_HALTED".into());
                    self.transition(FsmState::Complete);
                    break;
                }
                _ => results.push("ACTION_PENDING_FULL_DEVOPS_WIRING".into()),
            }
        }

        if self.current_state == FsmState::Executing { self.transition(FsmState::Complete); }
        Ok(results)
    }
}
