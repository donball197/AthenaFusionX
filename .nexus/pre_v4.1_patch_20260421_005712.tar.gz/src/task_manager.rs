// src/task_manager.rs — v3.2 SOVEREIGN CORTEX
use std::sync::{Arc, LazyLock};
use tokio::sync::{broadcast, Semaphore, Mutex};
use crate::agent_protocol::AgentAction;
use crate::json_parser;
use crate::executor::{RoboticExecutor, FsmState};
use crate::factory::AgentFactory;
use crate::logic_engine::LogicEngine;
use serde_json::json;

static TASK_SLAB: LazyLock<Arc<Semaphore>> = LazyLock::new(|| Arc::new(Semaphore::new(2)));

pub async fn send_task(
    orch: Arc<crate::orchestrator::Orchestrator>,
    client: &reqwest::Client,
    api_key: &str,
    directive: &str,
    memory: Arc<Mutex<crate::memory::MemoryPalace>>,
    vmo_state: Arc<tokio::sync::Mutex<crate::server::VmoState>>,
    tx: broadcast::Sender<String>,
) -> String {
    let _permit = TASK_SLAB.clone().acquire_owned().await.expect("SLAB_LOCK_FAIL");
    let mut session_obs = String::from("SENSORS_INIT: Substrate Ready.\n");
    let mut fsm = RoboticExecutor::new();
    let mut error_count: usize = 0;

    for turn in 1..=12 {
        if fsm.current_state == FsmState::Complete || fsm.current_state == FsmState::Fault { break; }

        let escalated_model = AgentFactory::get_model_for_turn(turn as usize, error_count);
        let prompt = format!("DIRECTIVE: {}\n\nOBSERVATIONS: {}\n\nExecute:", directive, session_obs);

        let ctx = crate::neural_agent::ContextPacket {
            system_prompt: Some(format!("You are NEXUS DEVOPS. Model: {}. You MUST output reasoning in <THOUGHT> and actions in <ACTION> JSON array.", escalated_model)),
            ..Default::default()
        };

        match orch.run(prompt, ctx, client, api_key, Some(tx.clone())).await {
            Ok(response) => {
                match json_parser::extract_actions(&response) {
                    Ok(actions) if !actions.is_empty() => {
                        match fsm.execute_handle(actions, memory.clone(), vmo_state.clone()).await {
                            Ok(results) => {
                                let combined = results.join("\n");
                                session_obs.push_str(&format!("RESULT: {}\n", combined));
                                error_count = 0;
                            }
                            Err(e) => {
                                error_count += 1;
                                session_obs.push_str(&format!("ERROR: {}\n", e));
                            }
                        }
                    }
                    _ => {
                        // ⚡ DIAGNOSTIC: Alert the user why we are escalating
                        let _ = tx.send(json!({"type": "NEURAL_STREAM", "payload": "\n\x1b[33m>> [CORTEX] Valid <ACTION> block not found. Escalating and retrying...\x1b[0m\n"}).to_string());
                        session_obs.push_str("SYSTEM: Failed to parse <ACTION> block from your last response. Use the correct JSON schema.\n");
                        error_count += 1;
                    }
                }
            }
            Err(e) => {
                let _ = tx.send(json!({"type": "NEURAL_STREAM", "payload": format!("\n\x1b[31m>> [API_ERROR]: {}\x1b[0m\n", e)}).to_string());
                break;
            }
        }
    }
    "TASK_COMPLETE".into()
}
